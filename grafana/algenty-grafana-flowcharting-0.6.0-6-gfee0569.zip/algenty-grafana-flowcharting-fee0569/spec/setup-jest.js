// setup-jest.js

import lodash from 'lodash';
global._ = lodash;

import $ from "jquery";
global.$ = $;

import * as moment from "moment";
global.moment = moment;

import angular from "angular";
global.angular = angular;

import GFP from "../src/plugin";
global.GFP = GFP;
