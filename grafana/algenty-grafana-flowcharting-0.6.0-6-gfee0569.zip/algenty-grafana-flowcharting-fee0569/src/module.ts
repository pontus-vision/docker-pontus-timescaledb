import { FlowchartCtrl } from './flowchart_ctrl';
// import { loadPluginCss } from '@grafana/runtime';
import grafana from './grafana_func';

grafana.loadCss();

// loadPluginCss({
//   dark: 'plugins/agenty-flowcharting-panel/styles/dark.css',
//   light: 'plugins/agenty-flowcharting-panel/styles/light.css',
// });

export { FlowchartCtrl as PanelCtrl };
